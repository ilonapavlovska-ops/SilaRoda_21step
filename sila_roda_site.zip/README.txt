
📄 Как опубликовать сайт через GitHub Pages:

1. Перейди на https://github.com и войди в свой аккаунт.
2. Создай новый репозиторий (например, SilaRoda_21step) — выбери Public.
3. Зайди в репозиторий → нажми 'Add file' → 'Upload files'.
4. Загрузите этот файл index.html из архива.
5. Нажми "Commit changes".
6. Перейди во вкладку Settings → Pages.
7. В разделе "Build and deployment":
   - Выбери Source: Deploy from a branch
   - Branch: main
   - Folder: /(root)
   - Нажми Save
8. Через 10–30 секунд твой сайт будет доступен по ссылке:
   https://твоё-имя.github.io/имя-репозитория/

🎉 Теперь можешь делиться ссылкой с кем угодно!
